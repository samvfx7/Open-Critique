// Prototype thresholds: no pre-existing rank thresholds were present.
// Keep these centralized so production thresholds can replace them directly.
export const RANKS = [
  { name: "Beginner", stone: "Bronze", threshold: 0, color: "#aa7955" },
  { name: "Novice", stone: "Silver", threshold: 100, color: "#bdc4ce" },
  { name: "Apprentice", stone: "Jade", threshold: 250, color: "#639b83" },
  { name: "Intermediate", stone: "Garnet", threshold: 500, color: "#914351" },
  { name: "Skilled", stone: "Topaz", threshold: 900, color: "#bc9360" },
  { name: "Advanced", stone: "Citrine", threshold: 1400, color: "#c4a851" },
  { name: "Elite", stone: "Sapphire", threshold: 2100, color: "#536fa6" },
  { name: "Expert", stone: "Emerald", threshold: 3000, color: "#408671" },
  { name: "Master", stone: "Ruby", threshold: 4200, color: "#aa485d" },
  { name: "Grandmaster", stone: "Amethyst", threshold: 5800, color: "#9174b6" },
  { name: "Legend", stone: "Opal", threshold: 7800, color: "#c1c9c7" },
  { name: "Apex", stone: "Diamond", threshold: 10000, color: "#dce2e9" },
] as const
export function getRank(xp: number) {
  const index = RANKS.reduce((n, r, i) => (xp >= r.threshold ? i : n), 0)
  const current = RANKS[index]
  const next = RANKS[index + 1]
  return {
    index,
    current,
    next,
    remaining: next ? Math.max(0, next.threshold - xp) : 0,
    progress: next
      ? Math.min(
          1,
          Math.max(
            0,
            (xp - current.threshold) / (next.threshold - current.threshold),
          ),
        )
      : 1,
  }
}
export const TASK_XP = {
  EASY: 10,
  MODERATE: 20,
  HARD: 35,
  VERY_HARD: 50,
} as const
export type Difficulty = keyof typeof TASK_XP
export type Task = {
  id: string
  name: string
  description: string
  difficulty: Difficulty
}
export type TaskCompletion = {
  id: string
  date: string
  xp: number
}
export const TASKS: Task[] = [
  {
    id: "foundation-form",
    name: "Review your technique",
    description: "Read the cues for today’s first three movements.",
    difficulty: "EASY",
  },
  {
    id: "foundation-mobility",
    name: "Make time for mobility",
    description: "Complete 10 minutes of comfortable, gentle movement.",
    difficulty: "MODERATE",
  },
  {
    id: "foundation-control",
    name: "Practice controlled movement",
    description: "Complete 20 minutes of deliberate technique practice.",
    difficulty: "HARD",
  },
  {
    id: "foundation-reflection",
    name: "Reflect and refine your plan",
    description:
      "Review your training and thoughtfully update your preferences.",
    difficulty: "VERY_HARD",
  },
]
// Preserved from the existing implementation: partial sessions earn no XP.
export const WORKOUT_POLICY = { fullCompletionXP: 50, partialCompletionXP: 0 }
export type MeasurementType = "REPS" | "WEIGHT_REPS" | "DURATION" | "DISTANCE"
export type ExerciseData = {
  name: string
  cue: string
  reps: string
  type: string
  measurement?: MeasurementType
  target?: number
  restRequired?: boolean
}
export type MeasurementEntry = {
  reps?: number
  weight?: number
  distance?: number
  seconds?: number
  running?: boolean
}
export function measurementType(e: ExerciseData): MeasurementType {
  return (
    e.measurement ||
    (/dumbbell|goblet|deadlift|overhead press/i.test(e.name)
      ? "WEIGHT_REPS"
      : "REPS")
  )
}
export function measurementLabel(e: ExerciseData) {
  const type = measurementType(e)
  return type === "DURATION"
    ? `${e.target || 60} sec`
    : type === "DISTANCE"
      ? `${e.target || 0.5} km`
      : `${e.reps} reps${type === "WEIGHT_REPS" ? " · kg" : ""}`
}
export type CoachEntry = {
  id: string
  role: "user" | "coach"
  text: string
}
export function coachReply(
  input: string,
  context: {
    title: string
    plan: ExerciseData[]
    goal: string
    environment: string
    days: number
    historyCount: number
    minutes: number
  },
): string {
  const q = input.toLowerCase()
  const exercise =
    context.plan.find((e) => q.includes(e.name.toLowerCase())) ||
    context.plan[0]
  if (/pain|injur|hurt|medical/.test(q))
    return "Stop any movement that causes pain. I can’t diagnose symptoms or provide medical advice. Consult a qualified clinician before continuing if discomfort persists."
  if (/explain|form|technique|squat|press|deadlift|row/.test(q))
    return `${exercise.name}: ${exercise.cue} Your target is ${measurementLabel(exercise)}. Work within a comfortable range and stop if you feel pain.`
  if (/recent|review|progress|history/.test(q))
    return context.historyCount
      ? `Your saved history contains ${context.historyCount} sessions and ${context.minutes} minutes of training. That’s recorded activity, not an assessment of your form or fitness. Review your summaries in Profile and adjust your training if recovery feels difficult.`
      : "You haven’t saved a workout yet. After your first session, you can review your actual training history in Profile. There’s no need to rush."
  if (/preference|plan|goal|schedule/.test(q))
    return `Your current goal is ${context.goal.toLowerCase()}, with ${context.days} training days per week in ${context.environment.toLowerCase()}. Edit your preferences in Profile to regenerate your plan. Recovery days are part of that schedule.`
  if (/today|training|workout/.test(q))
    return `Your selected session is ${context.title}, with ${context.plan.length} exercises. Begin with a gentle warm-up, then follow the targets and technique cues. Keep two comfortable reps in reserve for strength work.`
  return "I’m a local coaching prototype, not a connected AI service. I can explain your current exercises, summarize saved training, or discuss your preferences. Try “Explain my first exercise” or “Review recent training.”"
}
