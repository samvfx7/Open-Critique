import { useEffect, useRef, useState, useId, type ReactNode } from "react"
import {
  RANKS,
  TASK_XP,
  getRank,
  measurementType,
  measurementLabel,
  coachReply,
  type Task,
  type TaskCompletion,
  type ExerciseData,
  type MeasurementEntry,
  type CoachEntry,
} from "./domain"

export const DESTINATIONS = ["Home", "Workout", "AI Coach", "Profile"] as const
export function AppHeader({ children }: { children: ReactNode }) {
  return <header className="topbar">{children}</header>
}
export function FloatingBottomNavigation({
  selected,
  onSelect,
  icon,
}: {
  selected: string
  onSelect: (destination: string) => void
  icon: (destination: string) => ReactNode
}) {
  return (
    <nav
      className="bottom-nav glass glass-floating"
      aria-label="Primary navigation"
    >
      {DESTINATIONS.map((destination) => (
        <button
          key={destination}
          aria-current={selected === destination ? "page" : undefined}
          className={selected === destination ? "active" : ""}
          onClick={() => onSelect(destination)}
        >
          {icon(destination)}
          <span>{destination}</span>
        </button>
      ))}
    </nav>
  )
}
export function GlassOverlay({
  children,
  className = "",
  label,
}: {
  children: ReactNode
  className?: string
  label: string
}) {
  return (
    <div
      className={`overlay ${className}`}
      role="dialog"
      aria-modal="true"
      aria-label={label}
    >
      {children}
    </div>
  )
}
export function ProfileSection({
  title,
  children,
}: {
  title: string
  children: ReactNode
}) {
  return (
    <section className="profile-section">
      <div className="section-heading">
        <h2>{title}</h2>
      </div>
      {children}
    </section>
  )
}
export function LiquidGlassSurface({
  children,
  className = "",
  level = "supporting",
}: {
  children: ReactNode
  className?: string
  level?: "supporting" | "floating" | "overlay"
}) {
  return <div className={`glass glass-${level} ${className}`}>{children}</div>
}
export function RankGemstone({
  index,
  small = false,
}: {
  index: number
  small?: boolean
}) {
  const id = useId().replace(/:/g, "")
  const rank = RANKS[index]
  return (
    <svg
      className={`rank-gem ${small ? "gem-small" : ""}`}
      viewBox="0 0 200 180"
      role="img"
      aria-label={`${rank.stone} gemstone`}
    >
      <defs>
        <linearGradient id={`${id}-base`} x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="white" stopOpacity=".7" />
          <stop offset=".3" stopColor={rank.color} />
          <stop offset="1" stopColor={rank.color} stopOpacity=".4" />
        </linearGradient>
        <linearGradient id={`${id}-shine`} x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="white" stopOpacity=".65" />
          <stop offset="1" stopColor="white" stopOpacity="0" />
        </linearGradient>
        <radialGradient id={`${id}-halo`}>
          <stop stopColor="white" stopOpacity=".08" />
          <stop offset="1" stopColor="white" stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="153" rx="61" ry="12" fill="black" opacity=".28" />
      <circle cx="100" cy="87" r="86" fill={`url(#${id}-halo)`} />
      <g
        stroke="white"
        strokeOpacity=".2"
        strokeWidth=".6"
        strokeLinejoin="round"
      >
        <path d="M56 31 144 31 175 75 100 150 25 75Z" fill={rank.color} />
        <path
          d="m56 31 44 14 44-14 31 44-75 75-75-75Z"
          fill={`url(#${id}-base)`}
        />
        <path d="m56 31 13 44H25Z" fill="white" opacity=".24" />
        <path d="m56 31 44 14-31 30Z" fill="white" opacity=".42" />
        <path d="m100 45 44-14-13 44H69Z" fill="white" opacity=".15" />
        <path d="m144 31 31 44h-44Z" fill="black" opacity=".18" />
        <path d="M25 75h44l31 75Z" fill="black" opacity=".24" />
        <path d="M69 75h62l-31 75Z" fill={`url(#${id}-shine)`} />
        <path d="M131 75h44l-75 75Z" fill="black" opacity=".35" />
        <path
          d="m56 31 44 14 44-14M25 75h150M69 75l31-30 31 30-31 75Z"
          fill="none"
          strokeOpacity=".4"
        />
        {rank.stone === "Opal" && (
          <path d="M69 75h62l-31 75Z" fill="#b3b0cf" opacity=".25" />
        )}
      </g>
      <path
        d="m56 31 44 14 44-14"
        fill="none"
        stroke="white"
        strokeOpacity=".65"
        strokeWidth="1.2"
      />
    </svg>
  )
}
export function XPDisplay({ xp }: { xp: number }) {
  return (
    <span className="xp-display">
      {xp.toLocaleString()}
      <small> XP</small>
    </span>
  )
}
export function TrainingInsights({
  sessions,
  events,
}: {
  sessions: Array<Pick<TaskCompletion, "date">>
  events: Array<Pick<TaskCompletion, "date" | "xp">>
}) {
  const counts = [3, 2, 1, 0].map(
    (week) =>
      sessions.filter((s) => {
        const days = (Date.now() - new Date(s.date).getTime()) / 86400000
        return days >= week * 7 && days < (week + 1) * 7
      }).length,
  )
  const sorted = events
    .slice()
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  const total = sorted.reduce((n, e) => n + e.xp, 0)
  let cumulative = 0
  const points = sorted.map((event, i) => {
    cumulative += event.xp
    return `${((i + 1) / sorted.length) * 390},${110 - (cumulative / Math.max(1, total)) * 95}`
  })
  return (
    <details className="training-insights">
      <summary>
        Training insights <span>Frequency & XP progression</span>
      </summary>
      <div className="chart-grid">
        <LiquidGlassSurface className="chart">
          <div className="section-heading">
            <h2>Workout frequency</h2>
            <span className="tiny-label">LAST 4 WEEKS</span>
          </div>
          <div
            className="bar-chart"
            role="img"
            aria-label={`Workouts per week, oldest to newest: ${counts.join(", ")}`}
          >
            {counts.map((count, i) => (
              <div key={i}>
                <span>{count}</span>
                <div className="bar-area">
                  <div
                    style={{
                      height: `${
                        count ? (count / Math.max(1, ...counts)) * 100 : 1
                      }%`,
                    }}
                  />
                </div>
                <small>{i === 3 ? "This week" : `${3 - i}w ago`}</small>
              </div>
            ))}
          </div>
        </LiquidGlassSurface>
        <LiquidGlassSurface className="chart">
          <div className="section-heading">
            <h2>XP progression</h2>
            <span className="tiny-label">ALL RECORDED ACTIVITY</span>
          </div>
          <div className="line-chart">
            <XPDisplay xp={total} />
            <svg
              viewBox="0 0 400 120"
              preserveAspectRatio="none"
              role="img"
              aria-label={`${total} XP earned across ${events.length} recorded activities`}
            >
              <path
                d="M0 30h400M0 70h400M0 110h400"
                stroke="white"
                opacity=".07"
              />
              <polyline
                points={`0,110 ${points.length ? points.join(" ") : "400,110"}`}
                fill="none"
                stroke="#a8adb5"
                strokeWidth="2"
              />
            </svg>
            <div>
              <small>First recorded activity</small>
              <small>Latest</small>
            </div>
          </div>
        </LiquidGlassSurface>
      </div>
    </details>
  )
}
export function RankProgress({ xp }: { xp: number }) {
  const r = getRank(xp)
  return (
    <div className="rank-progress">
      <div className="rank-progress-label">
        <span>{r.next ? `Next · ${r.next.name}` : "Apex · maximum rank"}</span>
        <span>
          {r.next
            ? `${r.remaining.toLocaleString()} XP remaining`
            : "Every session still counts"}
        </span>
      </div>
      <div
        className="progress-track"
        role="progressbar"
        aria-label="Rank progress"
        aria-valuenow={Math.round(r.progress * 100)}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div style={{ width: `${r.progress * 100}%` }} />
      </div>
      <div className="rank-scale">
        <span>{r.current.threshold.toLocaleString()} XP</span>
        <span>
          {r.next ? `${r.next.threshold.toLocaleString()} XP` : "MAX"}
        </span>
      </div>
    </div>
  )
}
export function RankModule({
  xp,
  onInspect,
}: {
  xp: number
  onInspect?: () => void
}) {
  const r = getRank(xp)
  return (
    <LiquidGlassSurface className="rank-module">
      <div className="gem-stage">
        <div className="gem-stage-ring" />
        <RankGemstone index={r.index} />
        <span>{r.current.stone.toUpperCase()}</span>
      </div>
      <div className="rank-details">
        <div className="rank-overline">
          <span>YOUR CURRENT RANK</span>
          <span>{String(r.index + 1).padStart(2, "0")} / 12</span>
        </div>
        <div className="rank-title-row">
          <h2>{r.current.name}</h2>
          <XPDisplay xp={xp} />
        </div>
        <p>Built through intention. Earned through action.</p>
        <RankProgress xp={xp} />
        {onInspect && (
          <button className="rank-inspect" onClick={onInspect}>
            Explore your progression <span>↗</span>
          </button>
        )}
      </div>
    </LiquidGlassSurface>
  )
}
export function TaskRow({
  task,
  done,
  onComplete,
}: {
  task: Task
  done?: TaskCompletion
  onComplete: () => void
}) {
  return (
    <div className={`task-row ${done ? "task-done" : ""}`}>
      <button
        className="task-check"
        disabled={!!done}
        onClick={onComplete}
        aria-label={done ? `${task.name} completed` : `Complete ${task.name}`}
        aria-pressed={!!done}
      >
        {done && (
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.7"
          >
            <path d="m5 12 4 4L19 6" />
          </svg>
        )}
      </button>
      <div>
        <strong>{task.name}</strong>
        <p>{task.description}</p>
        <span className="task-difficulty">
          {task.difficulty.replace("_", " ")}
        </span>
      </div>
      <span className="task-reward">
        {done ? "Earned" : `+${TASK_XP[task.difficulty]}`}
        <small>{done ? `+${done.xp} XP` : "XP"}</small>
      </span>
    </div>
  )
}
export function ActivityRow({
  title,
  date,
  xp,
  onClick,
  kind,
}: {
  title: string
  date: string
  xp: number
  kind: "task" | "workout"
  onClick?: () => void
}) {
  const content = (
    <>
      <div className="activity-symbol">
        {kind === "task" ? (
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
          >
            <path d="m5 12 4 4L19 6" />
          </svg>
        ) : (
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
          >
            <path d="M4 8v8m3-10v12m10-12v12m3-10v8M7 12h10" />
          </svg>
        )}
      </div>
      <div>
        <strong>{title}</strong>
        <span>
          {new Date(date).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
          })}{" "}
          · {kind === "task" ? "Task completed" : "Workout saved"}
        </span>
      </div>
      <span className="activity-xp">+{xp} XP</span>
      {onClick && <span>›</span>}
    </>
  )
  return onClick ? (
    <button className="activity-row" onClick={onClick}>
      {content}
    </button>
  ) : (
    <div className="activity-row">{content}</div>
  )
}
export function RankCollection({ xp }: { xp: number }) {
  const current = getRank(xp)
  const [selected, setSelected] = useState(current.index)
  return (
    <section className="rank-collection">
      <div className="section-heading">
        <h2>The twelve ranks</h2>
        <span className="tiny-label">YOUR LONG-TERM JOURNEY</span>
      </div>
      <div className="rank-collection-grid">
        {RANKS.map((r, i) => (
          <button
            key={r.name}
            className={`${i === selected ? "selected" : ""} ${
              i > current.index ? "locked-rank" : ""
            }`}
            onClick={() => setSelected(i)}
            aria-label={`Inspect ${r.name}, ${r.stone}, ${r.threshold} XP`}
          >
            <RankGemstone index={i} small />
            <strong>{r.name}</strong>
            <span>{r.stone}</span>
            <small>
              {i === current.index
                ? "CURRENT"
                : i < current.index
                  ? "ACHIEVED"
                  : `${r.threshold.toLocaleString()} XP`}
            </small>
          </button>
        ))}
      </div>
      <div className="rank-detail">
        <strong>
          {RANKS[selected].name} · {RANKS[selected].stone}
        </strong>
        <p>
          {selected <= current.index
            ? "You’ve reached this rank."
            : `${Math.max(0, RANKS[selected].threshold - xp).toLocaleString()} XP to reach this rank.`}{" "}
          Threshold: {RANKS[selected].threshold.toLocaleString()} XP.
        </p>
        <small>Rank thresholds are centralized prototype configuration.</small>
      </div>
    </section>
  )
}
export function MeasurementControl({
  exercise,
  entry,
  onChange,
  disabled,
}: {
  exercise: ExerciseData
  entry: MeasurementEntry
  onChange: (entry: MeasurementEntry) => void
  disabled: boolean
}) {
  const type = measurementType(exercise)
  return (
    <div className="measurement-control">
      <span className="measurement-type">{type.replace("_", " + ")}</span>
      {(type === "REPS" || type === "WEIGHT_REPS") && (
        <div className="measurement-inputs">
          <label>
            <span>REPS · TARGET {exercise.reps}</span>
            <input
              type="number"
              min="1"
              max="1000"
              inputMode="numeric"
              value={entry.reps ?? (parseInt(exercise.reps) || 10)}
              disabled={disabled}
              onChange={(e) =>
                onChange({
                  ...entry,
                  reps: Math.max(1, Math.min(1000, Number(e.target.value))),
                })
              }
            />
          </label>
          {type === "WEIGHT_REPS" && (
            <label>
              <span>WEIGHT · KG</span>
              <input
                type="number"
                min="0"
                max="1000"
                step=".5"
                inputMode="decimal"
                value={entry.weight ?? 0}
                disabled={disabled}
                onChange={(e) =>
                  onChange({
                    ...entry,
                    weight: Math.max(0, Math.min(1000, Number(e.target.value))),
                  })
                }
              />
            </label>
          )}
        </div>
      )}
      {type === "DURATION" && (
        <div className="duration-control">
          <div>
            <span>TARGET · {exercise.target || 60} SEC</span>
            <strong>
              {Math.floor((entry.seconds || 0) / 60)
                .toString()
                .padStart(2, "0")}
              :{((entry.seconds || 0) % 60).toString().padStart(2, "0")}
            </strong>
          </div>
          <button
            className="button-secondary"
            disabled={
              disabled || (entry.seconds || 0) >= (exercise.target || 60)
            }
            onClick={() => onChange({ ...entry, running: !entry.running })}
          >
            {entry.running ? "Pause timer" : "Start timer"}
          </button>
        </div>
      )}
      {type === "DISTANCE" && (
        <label className="distance-input">
          <span>DISTANCE · TARGET {exercise.target || 0.5} KM</span>
          <input
            type="number"
            min="0"
            max="1000"
            step=".1"
            inputMode="decimal"
            value={entry.distance ?? exercise.target ?? 0.5}
            disabled={disabled}
            onChange={(e) =>
              onChange({
                ...entry,
                distance: Math.max(0, Math.min(1000, Number(e.target.value))),
              })
            }
          />
          <small>km · self-reported, no GPS tracking</small>
        </label>
      )}
    </div>
  )
}
export function CoachMessage({ message }: { message: CoachEntry }) {
  return (
    <div className={`coach-message ${message.role}`}>
      <span className="message-author">
        {message.role === "coach" ? "OPENCRITIQUE COACH" : "YOU"}
      </span>
      <p>{message.text}</p>
    </div>
  )
}
export function CoachComposer({ onSend }: { onSend: (text: string) => void }) {
  const [text, setText] = useState("")
  return (
    <form
      className="coach-composer glass glass-floating"
      onSubmit={(e) => {
        e.preventDefault()
        if (text.trim()) {
          onSend(text.trim())
          setText("")
        }
      }}
    >
      <label className="sr-only" htmlFor="coach-input">
        Ask your coach
      </label>
      <input
        id="coach-input"
        placeholder="Ask about your training…"
        value={text}
        onChange={(e) => setText(e.target.value)}
        maxLength={1000}
        autoComplete="off"
      />
      <button disabled={!text.trim()} aria-label="Send message">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.7"
        >
          <path d="M12 19V5m-6 6 6-6 6 6" />
        </svg>
      </button>
    </form>
  )
}
export function CoachScreen({
  messages,
  onMessages,
  context,
  onPreferences,
}: {
  messages: CoachEntry[]
  onMessages: (messages: CoachEntry[]) => void
  context: Parameters<typeof coachReply>[1]
  onPreferences: () => void
}) {
  const end = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const viewport = window.visualViewport
    const update = () => {
      document.documentElement.style.setProperty(
        "--available-height",
        `${viewport?.height || window.innerHeight}px`,
      )
      document.body.dataset.keyboardOpen = String(
        !!viewport && window.innerHeight - viewport.height > 150,
      )
    }
    update()
    viewport?.addEventListener("resize", update)
    return () => {
      viewport?.removeEventListener("resize", update)
      document.documentElement.style.removeProperty("--available-height")
      delete document.body.dataset.keyboardOpen
    }
  }, [])
  useEffect(() => {
    if (messages.length)
      end.current?.scrollIntoView({
        block: "nearest",
        behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "auto"
          : "smooth",
      })
  }, [messages.length])
  function send(text: string) {
    onMessages([
      ...messages,
      { id: crypto.randomUUID(), role: "user", text },
      {
        id: crypto.randomUUID(),
        role: "coach",
        text: coachReply(text, context),
      },
    ])
  }
  return (
    <div className="page coach-page">
      <div className="coach-header">
        <div>
          <div className="eyebrow">GUIDANCE, WITHOUT THE NOISE</div>
          <h1>AI Coach</h1>
          <span className="coach-status">
            <span />
            Local prototype · no live AI connection
          </span>
        </div>
        <button className="button-secondary" onClick={onPreferences}>
          Preferences
        </button>
      </div>
      <div className="coach-conversation" role="log" aria-live="polite">
        {messages.length ? (
          messages.map((m) => <CoachMessage key={m.id} message={m} />)
        ) : (
          <div className="coach-welcome">
            <div className="coach-monogram">
              OC<span>/ COACH</span>
            </div>
            <h2>A clearer way forward.</h2>
            <p>
              Ask about your plan, understand a movement,
              <br />
              or reflect on the training you’ve recorded.
            </p>
            <CoachMessage
              message={{
                id: "welcome",
                role: "coach",
                text: `Your current focus is ${context.goal.toLowerCase()}. What would you like to work through today? These are local, rule-based sample responses, not personalized medical advice.`,
              }}
            />
          </div>
        )}
        <div ref={end} />
      </div>
      <div className="coach-bottom">
        <div className="coach-suggestions">
          {[
            "Today’s training",
            "Explain my first exercise",
            "Review recent training",
            "Discuss preferences",
          ].map((q) => (
            <button key={q} onClick={() => send(q)}>
              {q}
              <span>↗</span>
            </button>
          ))}
        </div>
        <CoachComposer onSend={send} />
        <p className="coach-disclaimer">
          Local guidance only. Listen to your body and seek qualified advice
          when needed.
        </p>
      </div>
    </div>
  )
}
