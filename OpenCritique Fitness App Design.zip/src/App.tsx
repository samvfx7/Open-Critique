import {
  TASKS,
  TASK_XP,
  WORKOUT_POLICY,
  getRank,
  measurementType,
  measurementLabel,
  type TaskCompletion,
  type CoachEntry,
  type ExerciseData,
  type MeasurementEntry,
} from "./domain"
import {
  RankModule,
  RankGemstone,
  RankCollection,
  TaskRow,
  ActivityRow,
  MeasurementControl,
  CoachScreen,
  LiquidGlassSurface,
  AppHeader,
  FloatingBottomNavigation,
  GlassOverlay,
  DESTINATIONS,
  TrainingInsights,
} from "./ProductUI"
import { useEffect, useState, useRef, type ReactNode } from "react"

type Prefs = {
  goal: string

  level: string

  environment: string

  days: number

  time: number

  avoid: string[]

  equipment: string[]

  notes: string
}
type Exercise = ExerciseData
type Session = {
  id: string

  title: string

  exercises: Exercise[]

  index: number

  set: number

  sets: number

  completed: number

  seconds: number

  paused: boolean

  rest: number | null

  restTotal: number

  restPaused: boolean

  measurements?: Record<string, MeasurementEntry>

  completedExercises?: number[]
}
type RecordItem = {
  id: string

  title: string

  sets: number

  exercises: number

  seconds: number

  date: string

  xp: number

  measurements?: Record<string, MeasurementEntry>
}
const defaults: Prefs = {
  goal: "Build strength",
  level: "Intermediate",
  environment: "Gym",
  days: 3,
  time: 45,
  avoid: [],
  equipment: ["Dumbbells"],
  notes: "",
}
const library: Exercise[] = [
  {
    name: "Goblet squat",
    cue: "Sit between your hips. Keep your chest tall.",
    reps: "10–12",
    type: "squat",
  },
  {
    name: "Dumbbell bench press",
    cue: "Lower with control. Keep your shoulder blades together.",
    reps: "8–10",
    type: "bench",
  },
  {
    name: "Dumbbell row",
    cue: "Pull your elbow toward your hip. Keep your back neutral.",
    reps: "10–12",
    type: "row",
  },
  {
    name: "Romanian deadlift",
    cue: "Hinge at your hips. Keep the weights close.",
    reps: "10–12",
    type: "hinge",
  },
  {
    name: "Overhead press",
    cue: "Brace your core. Press straight overhead.",
    reps: "8–10",
    type: "press",
  },
  {
    name: "Dead bug",
    cue: "Keep your lower back grounded. Extend slowly.",
    reps: "10 / side",
    type: "core",
  },
]
function makePlan(p: Prefs): Exercise[] {
  let list = library.map((x) => ({ ...x }))
  if (
    p.environment === "Home without equipment" ||
    (p.environment === "Home with basic equipment" &&
      !p.equipment.includes("Dumbbells"))
  )
    list = [
      {
        name: "Bodyweight squat",
        cue: "Keep your heels grounded. Sit back with control.",
        reps: "12–15",
        type: "squat",
      },
      {
        name: "Incline push-up",
        cue: "Use a stable surface. Keep your body in one line.",
        reps: "8–12",
        type: "press",
      },
      {
        name: "Prone W raise",
        cue: "Squeeze your shoulder blades. Lift your hands slowly.",
        reps: "12–15",
        type: "row",
      },
      {
        name: "Glute bridge",
        cue: "Drive through your heels. Keep your ribs down.",
        reps: "12–15",
        type: "hinge",
      },
      {
        name: "Bird dog",
        cue: "Reach long. Keep your hips level.",
        reps: "8 / side",
        type: "core",
      },
      library[5],
    ]
  if (p.avoid.includes("Deep squats"))
    list[0] = {
      name: "Box squat",
      cue: "Sit onto a stable chair, then stand with control.",
      reps: "10–12",
      type: "squat",
    }
  if (p.avoid.includes("Overhead movements"))
    list[4] = {
      name: "Wall push-up",
      cue: "Keep your elbows close. Move with control.",
      reps: "12–15",
      type: "press",
    }
  if (p.goal === "Improve mobility")
    list = [
      {
        name: "Standing hip circles",
        cue: "Move slowly through a comfortable range.",
        reps: "8 / side",
        type: "squat",
      },
      {
        name: "Cat-cow",
        cue: "Move gently with your breath.",
        reps: "10",
        type: "core",
      },
      {
        name: "Standing shoulder circles",
        cue: "Keep your shoulders relaxed.",
        reps: "10 / side",
        type: "press",
      },
      library[5],
    ]
  if (p.goal === "Improve endurance")
    list = list.map((e) => ({ ...e, reps: "15–20" }))
  if (p.level === "Beginner")
    list = list.map((e) => ({
      ...e,
      reps: e.type === "core" ? "8 / side" : "8–10",
    }))
  if (p.goal === "Improve endurance")
    list = [
      {
        name: "Brisk walk",
        cue: "Keep a comfortable pace. You should still be able to speak.",
        reps: "",
        type: "walk",
        measurement: "DISTANCE",
        target: 0.5,
        restRequired: false,
      },
      ...list.slice(0, 3),
      {
        name: "Standing march",
        cue: "Stand tall. Lift your knees with control.",
        reps: "",
        type: "walk",
        measurement: "DURATION",
        target: 60,
        restRequired: false,
      },
    ]
  if (p.goal === "Improve mobility")
    list = list.map((e) => ({
      ...e,
      measurement: "DURATION" as const,
      target: 45,
      restRequired: false,
    }))
  return list.slice(0, p.time <= 25 ? 4 : 6)
}
interface IconProps {
  name: string
  size?: number
}
function Icon({ name, size = 20 }: IconProps) {
  const paths: Record<string, ReactNode> = {
    coach: (
      <>
        <path d="M4 4h16v12H9l-5 4Z" />
        <path d="M8 8h8M8 12h5" />
      </>
    ),
    home: (
      <>
        <path d="m3 10 9-7 9 7v10H3Z" />
        <path d="M9 20v-7h6v7" />
      </>
    ),
    workouts: (
      <>
        <rect x="4" y="5" width="16" height="16" rx="3" />
        <path d="M8 3v4m8-4v4M4 11h16m-11 4h2m2 0h2m-6 3h2" />
      </>
    ),
    progress: (
      <>
        <path d="M4 20V4m0 16h17M8 15l4-5 4 2 5-7" />
      </>
    ),
    profile: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21v-2a8 8 0 0 1 16 0v2" />
      </>
    ),
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    chevron: <path d="m9 5 7 7-7 7" />,
    back: <path d="m15 5-7 7 7 7" />,
    check: <path d="m5 12 4 4L19 6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    pause: (
      <>
        <path d="M8 5v14M16 5v14" />
      </>
    ),
    play: <path d="m8 5 11 7-11 7Z" />,
    close: <path d="m6 6 12 12M6 18 18 6" />,
    swap: (
      <>
        <path d="M4 8h16l-4-4m4 12H4l4 4" />
      </>
    ),
    spark: (
      <>
        <path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z" />
      </>
    ),
    equipment: (
      <>
        <path d="M8 12h8M4 8v8m3-10v12m10-12v12m3-10v8" />
      </>
    ),
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] || paths.spark}
    </svg>
  )
}
function Button({
  children,
  onClick,
  secondary = false,
  className = "",
  disabled = false,
}: {
  children: ReactNode

  onClick?: () => void

  secondary?: boolean

  className?: string

  disabled?: boolean
}) {
  return (
    <button
      disabled={disabled}
      className={`${
        secondary ? "button-secondary" : "button-primary"
      } ${className}`}
      onClick={onClick}
    >
      {children}
    </button>
  )
}
function Glass({
  children,
  className = "",
}: {
  children: ReactNode

  className?: string
}) {
  return <div className={`glass ${className}`}>{children}</div>
}
interface SectionProps {
  title: string
  aside?: ReactNode
}
function Section({ title, aside }: SectionProps) {
  return (
    <div className="section-heading">
      <h2>{title}</h2>
      {aside}
    </div>
  )
}
function Ring({
  value,
  children,
  large = false,
}: {
  value: number

  children: ReactNode

  large?: boolean
}) {
  return (
    <div className={`circular-progress ${large ? "ring-large" : ""}`}>
      <svg viewBox="0 0 120 120">
        <circle className="ring-track" cx="60" cy="60" r="54" />
        <circle
          className="ring-fill"
          cx="60"
          cy="60"
          r="54"
          strokeDasharray={`${Math.min(1, value) * 339.3} 339.3`}
        />
      </svg>
      <div>{children}</div>
    </div>
  )
}
function Movement({
  type = "squat",
  small = false,
}: {
  type?: string

  small?: boolean
}) {
  return (
    <svg
      className={small ? "movement small" : "movement"}
      viewBox="0 0 300 220"
      fill="none"
      aria-label={`${type} movement illustration`}
      role="img"
    >
      <defs>
        <linearGradient
          id="body"
          x1="90"
          y1="30"
          x2="220"
          y2="200"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#fff" />
          <stop offset="1" stopColor="#686b70" />
        </linearGradient>
      </defs>
      {!small && (
        <>
          <ellipse
            cx="153"
            cy="194"
            rx="95"
            ry="9"
            fill="white"
            opacity=".035"
          />
          <path d="M45 194h210" stroke="white" opacity=".1" />
          <circle cx="150" cy="113" r="82" stroke="white" opacity=".04" />
          <circle cx="150" cy="113" r="63" stroke="white" opacity=".04" />
        </>
      )}
      <g
        stroke="url(#body)"
        strokeWidth="13"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {type === "walk" ? (
          <>
            <circle cx="153" cy="47" r="14" fill="#a8adb5" strokeWidth="2" />
            <path d="m151 71-9 63 36 48m-36-48-25 48m31-91-29 30-20-13m49-17 24 25 22-14" />
            <path d="m110 186 20 1m44-2 21 1" strokeWidth="7" />
          </>
        ) : type === "bench" ? (
          <>
            <path
              d="M65 139h136m-124 0v47m109-47v47"
              strokeWidth="5"
              opacity=".35"
            />
            <circle cx="83" cy="117" r="13" fill="#a8adb5" strokeWidth="2" />
            <path d="m108 124 67 3 30 24-7 35m-78-62 6-51m1 51 22-33-3-20" />
            <path
              d="M111 65h29m-26-8v16m23-16v16m-1-8h25m-22-8v16m20-16v16m34 115h17"
              strokeWidth="7"
            />
          </>
        ) : type === "squat" ? (
          <>
            <circle cx="169" cy="47" r="14" fill="#a8adb5" strokeWidth="2" />
            <path d="m163 70-31 57 45 21-16 39m-27-58-27 23 9 35m45-109 29 30-30 14" />
            <path d="m154 187 22 1m-59-1 20 1" strokeWidth="7" />
            <path d="M157 115h29" strokeWidth="6" />
            <path d="M157 106v18m29-18v18" strokeWidth="10" />
          </>
        ) : type === "core" || type === "hinge" ? (
          <>
            <circle cx="88" cy="137" r="13" fill="#a8adb5" strokeWidth="2" />
            <path d="m111 146 65 7 28-45m-32 45 45 27m-97-34 3-45m-2 46 35-24" />
            <path d="m217 180 16 2" strokeWidth="7" />
          </>
        ) : type === "row" ? (
          <>
            <circle cx="168" cy="67" r="14" fill="#a8adb5" strokeWidth="2" />
            <path d="m155 89-43 48 18 47m-16-46 49 10 14 36m-39-76 40 12-6 31" />
            <path d="m124 186 22 1m24-2 20 1m-27-36h21" strokeWidth="7" />
          </>
        ) : (
          <>
            <circle cx="151" cy="61" r="14" fill="#a8adb5" strokeWidth="2" />
            <path d="M151 86v58m0-43-36 8-14-40m50 32 36 8 14-40m-50 75-26 43m26-43 25 43" />
            <path d="M87 65h28m72 0h28m-94 124h21m30 0h21" strokeWidth="7" />
            <path d="M90 56v18m22-18v18m78-18v18m22-18v18" strokeWidth="8" />
          </>
        )}
      </g>
    </svg>
  )
}
function ExerciseRow({
  exercise,
  index,
  sets,
  onReplace,
}: {
  exercise: Exercise

  index: number

  sets: number

  onReplace?: () => void
}) {
  return (
    <div className="exercise-row">
      <span className="exercise-number">
        {String(index + 1).padStart(2, "0")}
      </span>
      <div className="exercise-thumb">
        <Movement type={exercise.type} small />
      </div>
      <div className="exercise-text">
        <strong>{exercise.name}</strong>
        <span>
          {sets} sets <span className="dot">·</span>{" "}
          {measurementLabel(exercise)}
        </span>
      </div>
      {onReplace && (
        <button
          className="icon-button"
          aria-label={`Replace ${exercise.name}`}
          onClick={onReplace}
        >
          <Icon name="swap" size={17} />
        </button>
      )}
    </div>
  )
}
const formatTime = (n: number) =>
  `${Math.floor(n / 60)
    .toString()
    .padStart(2, "0")}:${(n % 60).toString().padStart(2, "0")}`
const dayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
const trainingDays = (n: number) =>
  n === 2
    ? [0, 3]
    : n === 3
      ? [0, 2, 4]
      : n === 4
        ? [0, 1, 3, 4]
        : n === 5
          ? [0, 1, 2, 4, 5]
          : [0, 1, 2, 3, 4, 5]
function load() {
  try {
    return JSON.parse(localStorage.getItem("opencritique-v1") || "null")
  } catch {
    return null
  }
}

export default function App() {
  const [saved] = useState(load)
  const [prefs, setPrefs] = useState<Prefs>(saved?.prefs || defaults)
  const [onboarded, setOnboarded] = useState<boolean>(saved?.onboarded || false)
  const [history, setHistory] = useState<RecordItem[]>(saved?.history || [])
  const [session, setSession] = useState<Session | null>(saved?.session || null)
  const [restDefault, setRestDefault] = useState<number>(
    saved?.restDefault || 60,
  )
  const [motion, setMotion] = useState<boolean>(saved?.motion ?? true)
  const [haptics, setHaptics] = useState<boolean>(saved?.haptics ?? false)
  const [taskCompletions, setTaskCompletions] = useState<TaskCompletion[]>(
    saved?.taskCompletions || [],
  )
  const [coachMessages, setCoachMessages] = useState<CoachEntry[]>(
    saved?.coachMessages || [],
  )
  const [rankUp, setRankUp] = useState<string | null>(null)
  const actionLock = useRef(false)
  const [tab, setTab] = useState("Home")
  const [screen, setScreen] = useState("main")
  const [onboarding, setOnboarding] = useState<number | null>(null)
  const [draft, setDraft] = useState<Prefs>(prefs)
  const [day, setDay] = useState(0)
  const [overrides, setOverrides] = useState<Record<number, Exercise>>({})
  const [confirm, setConfirm] = useState<string | null>(null)
  const [summary, setSummary] = useState<RecordItem | null>(null)
  const plan = makePlan(prefs).map((e, i) => overrides[i] || e)
  const sets =
    prefs.level === "Beginner" ? 2 : prefs.level === "Advanced" ? 4 : 3
  const xp =
    history.reduce((a, r) => a + r.xp, 0) +
    taskCompletions.reduce((a, t) => a + t.xp, 0)
  const rank = getRank(xp)
  const previousRank = useRef(rank.index)
  useEffect(() => {
    if (rank.index > previousRank.current) setRankUp(rank.current.name)
    previousRank.current = rank.index
  }, [rank.index, rank.current.name])
  useEffect(() => {
    if (!rankUp) return
    const t = setTimeout(() => setRankUp(null), 3500)
    return () => clearTimeout(t)
  }, [rankUp])
  useEffect(() => {
    actionLock.current = false
  }, [session?.index, session?.set, session?.rest, session?.id])
  const temporaryOverlay = useRef(false)
  temporaryOverlay.current = confirm !== null || onboarding !== null
  useEffect(() => {
    const overlays = document.querySelectorAll<HTMLElement>(".overlay")
    const overlay = overlays[overlays.length - 1]
    if (!overlay) return
    const previous = document.activeElement as HTMLElement | null
    const focusable = () =>
      Array.from(
        overlay.querySelectorAll<HTMLElement>(
          "button:not(:disabled), input:not(:disabled), select, textarea, [tabindex='0']",
        ),
      )
    focusable()[0]?.focus()
    const trap = (event: KeyboardEvent) => {
      if (event.key !== "Tab") return
      const items = focusable()
      const first = items[0],
        last = items[items.length - 1]
      if (
        event.shiftKey &&
        (document.activeElement === first ||
          !overlay.contains(document.activeElement))
      ) {
        event.preventDefault()
        last?.focus()
      } else if (
        !event.shiftKey &&
        (document.activeElement === last ||
          !overlay.contains(document.activeElement))
      ) {
        event.preventDefault()
        first?.focus()
      }
    }
    document.addEventListener("keydown", trap)
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    return () => {
      document.removeEventListener("keydown", trap)
      document.body.style.overflow = previousOverflow
      if (previous?.isConnected) previous.focus()
    }
  }, [
    confirm,
    onboarding !== null,
    session?.paused,
    session?.rest !== null && session !== null,
    screen,
  ])
  function completeTask(id: string) {
    const task = TASKS.find((t) => t.id === id)
    if (!task) return
    setTaskCompletions((prev) =>
      prev.some((t) => t.id === id)
        ? prev
        : [
            ...prev,
            {
              id,
              date: new Date().toISOString(),
              xp: TASK_XP[task.difficulty],
            },
          ],
    )
  }
  const activities = [
    ...history.map((r) => ({ ...r, kind: "workout" as const })),
    ...taskCompletions.map((t) => ({
      ...t,
      title: TASKS.find((x) => x.id === t.id)?.name || "Completed task",
      kind: "task" as const,
    })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  const weekStart = new Date()
  weekStart.setHours(0, 0, 0, 0)
  weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7))
  const weekHistory = history.filter((r) => new Date(r.date) >= weekStart)
  const weekCount = weekHistory.length
  const workoutTitle =
    prefs.goal === "Improve mobility"
      ? "Mobility & control"
      : day === 2
        ? "Full body · B"
        : day === 4
          ? "Full body · C"
          : "Full body · A"
  useEffect(() => {
    localStorage.setItem(
      "opencritique-v1",
      JSON.stringify({
        prefs,
        onboarded,
        history,
        session,
        restDefault,
        motion,
        haptics,
        taskCompletions,
        coachMessages,
      }),
    )
  }, [
    prefs,
    onboarded,
    history,
    session,
    restDefault,
    motion,
    haptics,
    taskCompletions,
    coachMessages,
  ])
  useEffect(() => {
    const interval = window.setInterval(
      () =>
        setSession((s) => {
          if (!s || temporaryOverlay.current) return s
          let next = { ...s, seconds: s.seconds + (s.paused ? 0 : 1) }
          if (s.rest !== null && !s.restPaused && !s.paused)
            next = { ...next, rest: s.rest <= 1 ? null : s.rest - 1 }
          const key = `${s.index}-${s.set}`
          const entry = s.measurements?.[key]
          if (entry?.running && !s.paused && s.rest === null) {
            const seconds = Math.min(
              (entry.seconds || 0) + 1,
              s.exercises[s.index].target || 60,
            )
            next = {
              ...next,
              measurements: {
                ...s.measurements,
                [key]: {
                  ...entry,
                  seconds,
                  running: seconds < (s.exercises[s.index].target || 60),
                },
              },
            }
          }
          return next
        }),
      1000,
    )
    return () => clearInterval(interval)
  }, [])
  function openOnboarding() {
    setDraft(prefs)
    setOnboarding(0)
  }
  function start() {
    if (!onboarded) {
      openOnboarding()
      return
    }
    if (!session)
      setSession({
        id: crypto.randomUUID(),
        title: workoutTitle,
        exercises: plan,
        index: 0,
        set: 1,
        sets,
        completed: 0,
        seconds: 0,
        paused: false,
        rest: null,
        restTotal: restDefault,
        restPaused: false,
      })
    else setSession((s) => s && { ...s, paused: false })
    setScreen("active")
  }
  function finish(s: Session) {
    const full = s.completed === s.exercises.length * s.sets
    const r: RecordItem = {
      id: s.id,
      title: s.title + (full ? "" : " · Partial session"),
      sets: s.completed,
      exercises:
        s.completedExercises?.length ??
        Math.min(s.exercises.length, Math.floor(s.completed / s.sets)),
      seconds: s.seconds,
      date: new Date().toISOString(),
      xp: full
        ? WORKOUT_POLICY.fullCompletionXP
        : WORKOUT_POLICY.partialCompletionXP,
      measurements: s.measurements,
    }
    setHistory((h) => (h.some((x) => x.id === r.id) ? h : [r, ...h]))
    setSummary(r)
    setSession(null)
    setScreen("complete")
    setConfirm(null)
  }
  function completeSet(skip = false) {
    if (
      !session ||
      session.paused ||
      session.rest !== null ||
      actionLock.current
    )
      return
    actionLock.current = true
    const key = `${session.index}-${session.set}`
    const exercise = session.exercises[session.index]
    const measurement = measurementType(exercise)
    const defaultEntry: MeasurementEntry =
      measurement === "DURATION"
        ? { seconds: 0 }
        : measurement === "DISTANCE"
          ? { distance: exercise.target || 0.5 }
          : {
              reps: parseInt(exercise.reps) || 10,
              ...(measurement === "WEIGHT_REPS" ? { weight: 0 } : {}),
            }
    const measurements = {
      ...session.measurements,
      ...(!skip
        ? {
            [key]: {
              ...defaultEntry,
              ...session.measurements?.[key],
              running: false,
            },
          }
        : {}),
    }
    const completedExercises = [...(session.completedExercises || [])]
    if (!skip && session.set === session.sets)
      completedExercises.push(session.index)
    const done =
      !skip && session.set < session.sets
        ? { ...session, set: session.set + 1, completed: session.completed + 1 }
        : {
            ...session,
            index: session.index + 1,
            set: 1,
            completed: session.completed + (skip ? 0 : 1),
          }
    if (haptics && navigator.vibrate) navigator.vibrate(15)
    if (done.index >= done.exercises.length) {
      finish({
        ...done,
        measurements,
        completedExercises,
        index: session.exercises.length - 1,
      })
      return
    }
    setSession({
      ...done,
      measurements,
      completedExercises,
      rest:
        skip || session.exercises[session.index].restRequired === false
          ? null
          : restDefault,
      restTotal: restDefault,
      restPaused: false,
    })
  }
  function replace(i: number) {
    const e = plan[i]
    const alt: Exercise =
      e.type === "squat"
        ? {
            name: "Sit-to-stand",
            reps: "12–15",
            cue: "Stand from a stable chair with control.",
            type: "squat",
          }
        : e.type === "press" || e.type === "bench"
          ? {
              name: "Wall push-up",
              reps: "12–15",
              cue: "Keep your elbows close to your body.",
              type: "press",
            }
          : e.type === "row"
            ? {
                name: "Prone reverse fly",
                reps: "12–15",
                cue: "Lift gently and squeeze your shoulder blades.",
                type: "row",
              }
            : {
                name: "Bird dog",
                reps: "10 / side",
                cue: "Keep your hips level as you reach.",
                type: "core",
              }
    setOverrides((o) => ({ ...o, [i]: alt }))
  }
  function Week({ interactive = false }: { interactive?: boolean }) {
    return (
      <div className="week">
        {dayNames.map((d, i) => {
          const done = weekHistory.some(
            (r) => (new Date(r.date).getDay() + 6) % 7 === i,
          )
          return (
            <button
              key={d}
              onClick={() => interactive && setDay(i)}
              className={`day ${i === day && interactive ? "selected" : ""}`}
              disabled={!interactive}
            >
              <span>{d}</span>
              <div
                className={`${done ? "done" : ""} ${
                  trainingDays(prefs.days).includes(i) ? "planned" : ""
                }`}
              >
                {done ? (
                  <Icon name="check" size={15} />
                ) : trainingDays(prefs.days).includes(i) ? (
                  <span className="day-dot" />
                ) : (
                  <span className="rest-dash">—</span>
                )}
              </div>
              {interactive && (
                <small>
                  {trainingDays(prefs.days).includes(i) ? "Train" : "Rest"}
                </small>
              )}
            </button>
          )
        })}
      </div>
    )
  }
  const nav = (
    <FloatingBottomNavigation
      selected={tab}
      onSelect={(t) => {
        setTab(t)
        setScreen("main")
      }}
      icon={(t) => (
        <Icon
          name={
            t === "AI Coach"
              ? "coach"
              : t === "Workout"
                ? "workouts"
                : t.toLowerCase()
          }
        />
      )}
    />
  )
  return (
    <div className={`app ${!motion ? "no-motion" : ""}`}>
      {rankUp && (
        <div className="rank-toast glass" role="status">
          <RankGemstone index={rank.index} small />
          <div>
            <strong>{rankUp} reached.</strong>
            <span>A new rank. The same intention.</span>
          </div>
        </div>
      )}
      <aside className="desktop-sidebar">
        <div className="wordmark">
          Open<span>Critique</span>
          <i />
        </div>
        <span className="sidebar-caption">BUILT FOR YOUR BETTER.</span>
        <div className="sidebar-menu">
          {DESTINATIONS.map((t) => (
            <button
              key={t}
              onClick={() => {
                setTab(t)
                setScreen("main")
              }}
              className={tab === t && screen === "main" ? "selected" : ""}
            >
              <Icon
                name={
                  t === "AI Coach"
                    ? "coach"
                    : t === "Workout"
                      ? "workouts"
                      : t.toLowerCase()
                }
              />
              {t}
              {tab === t && <span className="nav-indicator" />}
            </button>
          ))}
        </div>
        <div className="sidebar-bottom">
          <div className="little-orbit">
            <Icon name="spark" />
          </div>
          <strong>Progress, not perfection.</strong>
          <p>One intentional session at a time.</p>
          <div className="sidebar-rule" />
          <span>PERSONAL TRAINING, REDEFINED</span>
          <small>OpenCritique © {new Date().getFullYear()}</small>
        </div>
      </aside>
      <main className="main-shell">
        <AppHeader>
          <div className="mobile-wordmark wordmark">
            Open<span>Critique</span>
            <i />
          </div>
          <div className="breadcrumb">
            <span>Your space</span>
            <Icon name="chevron" size={12} />
            <strong>
              {screen === "active"
                ? "In session"
                : screen === "complete"
                  ? "Session complete"
                  : tab}
            </strong>
          </div>
          <div className="topbar-right">
            <span className="local-badge">
              <span />
              LOCAL PROTOTYPE
            </span>
            <button
              className="avatar"
              aria-label="Open profile"
              onClick={() => {
                setTab("Profile")
                setScreen("main")
              }}
            >
              OC
            </button>
          </div>
        </AppHeader>
        {screen === "main" && tab === "Home" && (
          <div className="page home-page">
            <div className="dashboard-greeting">
              <div>
                <h1>
                  {new Date().getHours() < 12
                    ? "Good morning."
                    : new Date().getHours() < 18
                      ? "Good afternoon."
                      : "Good evening."}
                </h1>
                <p>Here’s where you are. Here’s what comes next.</p>
              </div>
              <div className="dashboard-date">
                {new Date().toLocaleDateString("en-US", {
                  weekday: "long",
                  month: "short",
                  day: "numeric",
                })}
              </div>
            </div>
            <RankModule xp={xp} onInspect={() => setTab("Profile")} />
            <section className="dashboard-section">
              <Section
                title="Today’s training"
                aside={
                  <span className="tiny-label">
                    {onboarded ? "YOUR PERSONAL PLAN" : "SAMPLE PLAN"}
                  </span>
                }
              />
              <LiquidGlassSurface className="training-module">
                <div className="training-heading">
                  <div>
                    <span className="eyebrow">
                      {prefs.goal === "Improve mobility"
                        ? "MOBILITY & CONTROL"
                        : prefs.goal === "Improve endurance"
                          ? "ENDURANCE & MOVEMENT"
                          : "STRENGTH · FULL BODY"}
                    </span>
                    <h3>{workoutTitle}</h3>
                    <p>
                      {prefs.environment} · {sets} sets per movement
                    </p>
                  </div>
                  <Movement type={plan[0].type} />
                </div>
                <div className="training-meta">
                  <span>
                    <Icon name="clock" size={15} />
                    {prefs.time} min
                  </span>
                  <span>
                    <Icon name="equipment" size={16} />
                    {plan.length} exercises
                  </span>
                </div>
                {plan.slice(0, 3).map((e, i) => (
                  <ExerciseRow
                    key={e.name}
                    exercise={e}
                    index={i}
                    sets={sets}
                  />
                ))}
                <div className="training-footer">
                  <button onClick={() => setTab("Workout")}>
                    View full session ↗
                  </button>
                  <Button onClick={start}>
                    {session ? "Resume Workout" : "Start Workout"}
                    <Icon name="arrow" size={17} />
                  </Button>
                </div>
                {!onboarded && (
                  <button className="rank-inspect" onClick={openOnboarding}>
                    Personalize your training plan ↗
                  </button>
                )}
              </LiquidGlassSurface>
            </section>
            <section className="dashboard-section">
              <Section
                title="Today’s tasks"
                aside={
                  <span className="tiny-label">
                    {taskCompletions.length} / {TASKS.length} COMPLETE
                  </span>
                }
              />
              <p className="section-subtitle">
                Intentional actions. One reward per completed task.
              </p>
              {TASKS.map((t) => (
                <TaskRow
                  key={t.id}
                  task={t}
                  done={taskCompletions.find((c) => c.id === t.id)}
                  onComplete={() => completeTask(t.id)}
                />
              ))}
            </section>
            <section className="dashboard-section">
              <Section
                title="Recent activity"
                aside={
                  <button
                    className="rank-inspect"
                    onClick={() => setTab("Profile")}
                  >
                    View all ↗
                  </button>
                }
              />
              {activities.length ? activities.slice(0, 5).map((a) => (
                  <ActivityRow
                    key={a.id}
                    title={a.title}
                    date={a.date}
                    xp={a.xp}
                    kind={a.kind}
                    onClick={
                      a.kind === "workout"
                        ? () => {
                            setSummary(
                              history.find((r) => r.id === a.id) || null,
                            )
                            setScreen("summary")
                          }
                        : undefined
                    }
                  />
                )) : <p className="activity-empty">
                  Your completed workouts and tasks will appear here.
                </p>}
            </section>
          </div>
        )}
        {screen === "main" && tab === "Workout" && (
          <div className="page">
            <div className="page-intro">
              <div>
                <div className="eyebrow">STRUCTURE WITH ROOM TO BREATHE</div>
                <h1>Your weekly plan.</h1>
                <p>
                  {prefs.days} sessions. Intentional movement. Essential
                  recovery.
                </p>
              </div>
              <Button secondary onClick={openOnboarding}>
                Edit preferences
                <Icon name="swap" size={16} />
              </Button>
            </div>
            <Glass className="schedule">
              <Week interactive />
            </Glass>
            <div className="plan-content">
              {trainingDays(prefs.days).includes(day) ? (
                <>
                  <div className="plan-heading">
                    <div>
                      <span className="eyebrow">
                        {dayNames[day].toUpperCase()} · STRENGTH & CONTROL
                      </span>
                      <h2>{workoutTitle}</h2>
                      <p>
                        {prefs.time} minutes · {plan.length} exercises ·{" "}
                        {prefs.environment}
                      </p>
                    </div>
                    <Button onClick={start}>
                      {session ? "Resume session" : "Begin workout"}
                      <Icon name="arrow" size={18} />
                    </Button>
                  </div>
                  <Section
                    title="The session"
                    aside={
                      <span className="tiny-label">
                        TAP ↔ TO REPLACE A MOVEMENT
                      </span>
                    }
                  />
                  <div className="full-exercises">
                    {plan.map((e, i) => (
                      <div key={i}>
                        <ExerciseRow
                          exercise={e}
                          index={i}
                          sets={sets}
                          onReplace={() => replace(i)}
                        />
                        <p className="row-cue">{e.cue}</p>
                      </div>
                    ))}
                  </div>
                  <Glass className="tip">
                    <Icon name="spark" />
                    <p>
                      <strong>Start steady.</strong> Spend 5 minutes warming up.
                      Choose a weight that leaves 2 comfortable reps in reserve.
                    </p>
                  </Glass>
                </>
              ) : (
                <div className="rest-day">
                  <Ring value={1}>
                    <Icon name="spark" size={36} />
                  </Ring>
                  <h2>Recovery is part of the plan.</h2>
                  <p>
                    A walk, a gentle stretch, or simply a little rest.
                    <br />
                    You don’t need to earn your recovery.
                  </p>
                  <Button
                    secondary
                    onClick={() => setDay(trainingDays(prefs.days)[0])}
                  >
                    View next session
                    <Icon name="arrow" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
        {screen === "main" && tab === "AI Coach" && (
          <CoachScreen
            messages={coachMessages}
            onMessages={setCoachMessages}
            onPreferences={openOnboarding}
            context={{
              title: workoutTitle,
              plan,
              goal: prefs.goal,
              environment: prefs.environment,
              days: prefs.days,
              historyCount: history.length,
              minutes: Math.round(
                history.reduce((a, r) => a + r.seconds, 0) / 60,
              ),
            }}
          />
        )}
        {screen === "main" && tab === "Profile" && (
          <div className="page profile-page">
            <div className="page-intro">
              <div>
                <div className="eyebrow">MADE TO FIT YOUR LIFE</div>
                <h1>Profile</h1>
                <p>Keep your preferences in step with where you are.</p>
              </div>
            </div>
            <Glass className="profile-hero">
              <div className="profile-avatar">OC</div>
              <div>
                <h2>OpenCritique athlete</h2>
                <p>
                  {rank.current.name} ·{" "}
                  <span className="xp-display">{xp.toLocaleString()} XP</span>
                </p>
              </div>
              <Button secondary onClick={openOnboarding}>
                Edit preferences
                <Icon name="arrow" />
              </Button>
            </Glass>
            <RankModule xp={xp} />
            <RankCollection xp={xp} />
            <div className="profile-summary">
              <div>
                <strong>{history.length}</strong>
                <span>Saved sessions</span>
              </div>
              <div>
                <strong>
                  {Math.round(history.reduce((n, r) => n + r.seconds, 0) / 60)}
                </strong>
                <span>Training minutes</span>
              </div>
              <div>
                <strong>{taskCompletions.length}</strong>
                <span>Completed tasks</span>
              </div>
              <div>
                <strong>
                  {weekCount} / {prefs.days}
                </strong>
                <span>Sessions this week</span>
              </div>
            </div>
            <TrainingInsights sessions={history} events={activities} />
            <Section title="Workout history" />
            {history.length ? (
              history.map((r) => (
                <ActivityRow
                  key={r.id}
                  title={r.title}
                  date={r.date}
                  xp={r.xp}
                  kind="workout"
                  onClick={() => {
                    setSummary(r)
                    setScreen("summary")
                  }}
                />
              ))
            ) : (
              <p className="activity-empty">No saved sessions yet.</p>
            )}
            <Section title="Completed tasks" />
            {taskCompletions.length ? (
              taskCompletions.map((t) => (
                <ActivityRow
                  key={t.id}
                  title={TASKS.find((x) => x.id === t.id)?.name || "Task"}
                  date={t.date}
                  xp={t.xp}
                  kind="task"
                />
              ))
            ) : (
              <p className="activity-empty">
                Your completed tasks will appear here.
              </p>
            )}
            <Section title="Training preferences" />
            <div className="settings-list">
              {[
                ["Goal", prefs.goal],
                ["Experience", prefs.level],
                ["Training environment", prefs.environment],
                [
                  "Equipment",
                  prefs.environment === "Home without equipment"
                    ? "None required"
                    : prefs.equipment.join(", ") || "Bodyweight",
                ],
                [
                  "Weekly schedule",
                  `${prefs.days} days · ${prefs.time} minute sessions`,
                ],
                [
                  "Movement limitations",
                  prefs.avoid.join(", ") || "None selected",
                ],
                [
                  "Additional preferences",
                  prefs.notes || "No additional preferences",
                ],
              ].map(([k, v]) => (
                <div className="setting-row" key={k}>
                  <span>{k}</span>
                  <strong>{v}</strong>
                </div>
              ))}
            </div>
            <Section title="The details" />
            <div className="setting-row">
              <div>
                <strong>Default rest duration</strong>
                <p>Time to recover between sets.</p>
              </div>
              <select
                aria-label="Default rest duration"
                value={restDefault}
                onChange={(e) => setRestDefault(Number(e.target.value))}
              >
                {[30, 45, 60, 90, 120].map((n) => (
                  <option key={n} value={n}>
                    {n} seconds
                  </option>
                ))}
              </select>
            </div>
            <div className="setting-row">
              <div>
                <strong>Interface motion</strong>
                <p>Subtle transitions, never a distraction.</p>
              </div>
              <button
                className={`toggle ${motion ? "on" : ""}`}
                role="switch"
                aria-checked={motion}
                aria-label="Interface motion"
                onClick={() => setMotion(!motion)}
              >
                <span />
              </button>
            </div>
            <div className="setting-row">
              <div>
                <strong>Haptic feedback</strong>
                <p>Gentle set feedback on supported devices.</p>
              </div>
              <button
                className={`toggle ${haptics ? "on" : ""}`}
                role="switch"
                aria-checked={haptics}
                aria-label="Haptic feedback"
                onClick={() => setHaptics(!haptics)}
              >
                <span />
              </button>
            </div>
            <div className="setting-row">
              <div>
                <strong>Reset local data</strong>
                <p>Clear your plan, sessions, and preferences.</p>
              </div>
              <Button secondary onClick={() => setConfirm("reset")}>
                Reset prototype
              </Button>
            </div>
          </div>
        )}
        {screen === "active" && session && (
          <div className="page active-page">
            <div className="session-header">
              <button
                className="icon-button"
                aria-label="Leave session and preserve progress"
                onClick={() => {
                  setSession((s) => s && { ...s, paused: true })
                  setScreen("main")
                }}
              >
                <Icon name="back" />
              </button>
              <div>
                <strong>{session.title}</strong>
                <span>
                  {session.completed} of{" "}
                  {session.exercises.length * session.sets} sets complete
                </span>
              </div>
              <span className="elapsed">
                <Icon name="clock" size={15} />
                {formatTime(session.seconds)}
              </span>
              <button
                className="icon-button"
                aria-label={session.paused ? "Resume session" : "Pause session"}
                onClick={() =>
                  setSession((s) => s && { ...s, paused: !s.paused })
                }
              >
                <Icon name={session.paused ? "play" : "pause"} />
              </button>
            </div>
            <div className="progress-track session-track">
              <div
                style={{
                  width: `${(session.completed / (session.exercises.length * session.sets)) * 100}%`,
                }}
              />
            </div>
            <div className="active-layout">
              <div className="active-art">
                <Movement type={session.exercises[session.index].type} />
                <span className="art-label">CONTROL OVER MOMENTUM.</span>
              </div>
              <div className="active-info">
                <span className="eyebrow">
                  EXERCISE {String(session.index + 1).padStart(2, "0")} /{" "}
                  {String(session.exercises.length).padStart(2, "0")}
                </span>
                <h1>{session.exercises[session.index].name}</h1>
                <p className="technique">
                  {session.exercises[session.index].cue}
                </p>
                <Glass className="set-display">
                  <div>
                    <span>TARGET</span>
                    <strong>
                      {measurementLabel(
                        session.exercises[session.index],
                      ).replace(" · kg", "")}
                    </strong>
                  </div>
                  <div>
                    <span>CURRENT SET</span>
                    <strong>
                      {session.set}
                      <small> / {session.sets}</small>
                    </strong>
                  </div>
                </Glass>
                <MeasurementControl
                  exercise={session.exercises[session.index]}
                  entry={
                    session.measurements?.[`${session.index}-${session.set}`] ||
                    {}
                  }
                  disabled={session.paused || session.rest !== null}
                  onChange={(entry) =>
                    setSession(
                      (s) =>
                        s && {
                          ...s,
                          measurements: {
                            ...s.measurements,
                            [`${s.index}-${s.set}`]: entry,
                          },
                        },
                    )
                  }
                />
                <div className="set-dots">
                  {Array.from({ length: session.sets }, (_, i) => (
                    <span
                      key={i}
                      className={
                        i < session.set - 1
                          ? "done"
                          : i === session.set - 1
                            ? "current"
                            : ""
                      }
                    >
                      {i < session.set - 1 ? (
                        <Icon name="check" size={13} />
                      ) : (
                        i + 1
                      )}
                    </span>
                  ))}
                  <small>Quality reps. Comfortable pace.</small>
                </div>
                <Button
                  className="complete-set"
                  disabled={session.paused || session.rest !== null}
                  onClick={() => completeSet()}
                >
                  <Icon name="check" />
                  {measurementType(session.exercises[session.index]) ===
                  "DURATION"
                    ? "Complete timed set"
                    : measurementType(session.exercises[session.index]) ===
                        "DISTANCE"
                      ? "Complete distance set"
                      : "Mark set complete"}
                  <Icon name="arrow" />
                </Button>
                <div className="session-secondary">
                  <button
                    disabled={session.paused || session.rest !== null}
                    onClick={() => completeSet(true)}
                  >
                    Skip exercise
                  </button>
                  <button onClick={() => setConfirm("end")}>End session</button>
                </div>
              </div>
            </div>
            {session.paused && session.rest === null && (
              <GlassOverlay className="" label="Workout paused">
                <Glass className="modal pause-modal">
                  <Icon name="pause" size={32} />
                  <h2>Take your time.</h2>
                  <p>Your progress is saved. Ready when you are.</p>
                  <Button
                    onClick={() =>
                      setSession((s) => s && { ...s, paused: false })
                    }
                  >
                    Resume workout
                    <Icon name="play" />
                  </Button>
                  <Button secondary onClick={() => setConfirm("end")}>
                    End session
                  </Button>
                </Glass>
              </GlassOverlay>
            )}
            {session.rest !== null && (
              <GlassOverlay className="rest-overlay" label="Rest timer">
                <Glass className="modal rest-modal">
                  <span className="eyebrow">BREATHE. RESET.</span>
                  <h2>A moment to recover.</h2>
                  <Ring value={session.rest / session.restTotal} large>
                    <strong>{formatTime(session.rest)}</strong>
                    <span>{session.restTotal} SECOND REST</span>
                  </Ring>
                  <div className="next-up">
                    <span>
                      UP NEXT · SET {session.set} OF {session.sets}
                    </span>
                    <strong>{session.exercises[session.index].name}</strong>
                  </div>
                  <div className="timer-controls">
                    <Button
                      secondary
                      onClick={() =>
                        setSession(
                          (s) =>
                            s && {
                              ...s,
                              restPaused: !(s.restPaused || s.paused),
                              paused: false,
                            },
                        )
                      }
                    >
                      <Icon
                        name={
                          session.restPaused || session.paused
                            ? "play"
                            : "pause"
                        }
                      />
                      {session.restPaused || session.paused
                        ? "Resume"
                        : "Pause"}
                    </Button>
                    <Button
                      secondary
                      onClick={() =>
                        setSession(
                          (s) =>
                            s && {
                              ...s,
                              rest: (s.rest || 0) + 15,
                              restTotal: s.restTotal + 15,
                            },
                        )
                      }
                    >
                      + 15 sec
                    </Button>
                  </div>
                  <Button
                    onClick={() =>
                      setSession(
                        (s) => s && { ...s, rest: null, paused: false },
                      )
                    }
                  >
                    Skip rest
                    <Icon name="arrow" />
                  </Button>
                </Glass>
              </GlassOverlay>
            )}
          </div>
        )}
        {(screen === "complete" || screen === "summary") && summary && (
          <div className="page completion">
            <span className="eyebrow">
              {screen === "complete"
                ? "YOU SHOWED UP FOR YOURSELF"
                : "YOUR SESSION, IN DETAIL"}
            </span>
            <Ring value={1}>
              <Icon name="check" size={40} />
            </Ring>
            <h1>
              {screen === "complete" ? "Good work. Truly." : summary.title}
            </h1>
            <p>
              {summary.title} · {new Date(summary.date).toLocaleDateString()}
            </p>
            <Glass className="completion-stats">
              {[
                [summary.exercises, "Exercises"],
                [summary.sets, "Sets completed"],
                [formatTime(summary.seconds), "Training time"],
                [`+${summary.xp}`, "XP earned"],
              ].map(([v, l]) => (
                <div key={l}>
                  <strong>{v}</strong>
                  <span>{l}</span>
                </div>
              ))}
            </Glass>
            <RankModule xp={xp} />
            <h3>
              {weekCount} of {prefs.days} sessions this week.
            </h3>
            <p>Strength grows with consistency. Recovery is your next step.</p>
            <div className="completion-actions">
              {screen === "complete" && (
                <Button secondary onClick={() => setScreen("summary")}>
                  View summary
                  <Icon name="progress" />
                </Button>
              )}
              <Button
                onClick={() => {
                  setScreen("main")
                  setTab("Home")
                }}
              >
                Return home
                <Icon name="arrow" />
              </Button>
            </div>
          </div>
        )}
        {screen !== "active" && nav}
      </main>
      {onboarding !== null && (
        <GlassOverlay
          className="onboarding-overlay"
          label="Training preferences"
        >
          <Glass className="modal onboarding-modal">
            <div className="modal-top">
              <div className="wordmark">
                Open<span>Critique</span>
                <i />
              </div>
              <button
                className="icon-button"
                aria-label="Close preferences"
                onClick={() => setOnboarding(null)}
              >
                <Icon name="close" />
              </button>
            </div>
            <div className="onboarding-progress">
              {Array.from({ length: 7 }, (_, i) => (
                <span className={i <= onboarding ? "filled" : ""} key={i} />
              ))}
            </div>
            <span className="eyebrow">
              YOUR FOUNDATION · {onboarding + 1} OF 7
            </span>
            <h2>
              {
                [
                  "A plan that starts with you.",
                  "What are you working toward?",
                  "Meet yourself where you are.",
                  "Where will you train?",
                  "Make room for consistency.",
                  "Your body. Your boundaries.",
                  "Your next chapter, planned.",
                ][onboarding]
              }
            </h2>
            <p>
              {
                [
                  "Intentional training. Clear guidance. Lasting progress. Let’s make it personal.",
                  "One clear direction. A plan designed to get you there.",
                  "We’ll adapt the volume and difficulty to your experience.",
                  "A good workout makes the most of what you have.",
                  "Recovery is built in. Choose a rhythm that fits your life.",
                  "Tell us what feels right. You can change these at any time.",
                  "A balanced full-body split, with space to recover.",
                ][onboarding]
              }
            </p>
            <div className="onboarding-body">
              {onboarding === 0 && (
                <div className="onboarding-intro">
                  <div className="abstract-orbit">
                    <span />
                    <span />
                    <span />
                    <Icon name="spark" size={32} />
                  </div>
                  <div className="intro-points">
                    <span>
                      <Icon name="check" size={16} />A plan that fits your life
                    </span>
                    <span>
                      <Icon name="check" size={16} />
                      Coaching for every movement
                    </span>
                    <span>
                      <Icon name="check" size={16} />
                      No account. No pressure.
                    </span>
                  </div>
                </div>
              )}
              {onboarding === 1 && (
                <div className="selections">
                  {[
                    "Build strength",
                    "Improve endurance",
                    "Develop general fitness",
                    "Improve mobility",
                    "Build a consistent exercise habit",
                  ].map((x) => (
                    <button
                      className={`selection ${
                        draft.goal === x ? "selected" : ""
                      }`}
                      key={x}
                      onClick={() => setDraft({ ...draft, goal: x })}
                    >
                      <span>{x}</span>
                      <span className="radio">
                        {draft.goal === x && <span />}
                      </span>
                    </button>
                  ))}
                </div>
              )}
              {onboarding === 2 && (
                <div className="selections">
                  {["Beginner", "Intermediate", "Advanced"].map((x, i) => (
                    <button
                      className={`selection ${
                        draft.level === x ? "selected" : ""
                      }`}
                      key={x}
                      onClick={() => setDraft({ ...draft, level: x })}
                    >
                      <div>
                        <strong>{x}</strong>
                        <small>
                          {
                            [
                              "Building a foundation, or coming back to training.",
                              "Comfortable with the basics and ready to progress.",
                              "Experienced, consistent, and confident in your form.",
                            ][i]
                          }
                        </small>
                      </div>
                      <span className="radio">
                        {draft.level === x && <span />}
                      </span>
                    </button>
                  ))}
                </div>
              )}
              {onboarding === 3 && (
                <>
                  <div className="selections">
                    {[
                      "Home without equipment",
                      "Home with basic equipment",
                      "Gym",
                    ].map((x) => (
                      <button
                        key={x}
                        className={`selection ${
                          draft.environment === x ? "selected" : ""
                        }`}
                        onClick={() => setDraft({ ...draft, environment: x })}
                      >
                        <span>{x}</span>
                        <span className="radio">
                          {draft.environment === x && <span />}
                        </span>
                      </button>
                    ))}
                  </div>
                  {draft.environment !== "Home without equipment" && (
                    <>
                      <label className="field-label">AVAILABLE EQUIPMENT</label>
                      <div className="chip-options">
                        {["Dumbbells", "Resistance bands", "Bench", "Mat"].map(
                          (x) => (
                            <button
                              key={x}
                              className={
                                draft.equipment.includes(x) ? "selected" : ""
                              }
                              onClick={() =>
                                setDraft({
                                  ...draft,
                                  equipment: draft.equipment.includes(x)
                                    ? draft.equipment.filter((e) => e !== x)
                                    : [...draft.equipment, x],
                                })
                              }
                            >
                              {x}
                            </button>
                          ),
                        )}
                      </div>
                    </>
                  )}
                </>
              )}
              {onboarding === 4 && (
                <>
                  <label className="field-label">SESSIONS PER WEEK</label>
                  <div className="day-select">
                    {[2, 3, 4, 5, 6].map((n) => (
                      <button
                        key={n}
                        className={draft.days === n ? "selected" : ""}
                        onClick={() => setDraft({ ...draft, days: n })}
                      >
                        {n}
                        <small>days</small>
                      </button>
                    ))}
                  </div>
                  <Glass className="tip">
                    <Icon name="clock" />
                    <p>
                      {7 - draft.days} recovery days. A sustainable rhythm beats
                      a perfect week.
                    </p>
                  </Glass>
                </>
              )}
              {onboarding === 5 && (
                <>
                  <label className="field-label">
                    MOVEMENTS TO AVOID · OPTIONAL
                  </label>
                  <div className="chip-options">
                    {["Deep squats", "Overhead movements", "Jumping"].map(
                      (x) => (
                        <button
                          key={x}
                          className={draft.avoid.includes(x) ? "selected" : ""}
                          onClick={() =>
                            setDraft({
                              ...draft,
                              avoid: draft.avoid.includes(x)
                                ? draft.avoid.filter((a) => a !== x)
                                : [...draft.avoid, x],
                            })
                          }
                        >
                          {x}
                        </button>
                      ),
                    )}
                  </div>
                  <label className="field-label">TIME FOR EACH SESSION</label>
                  <div className="chip-options">
                    {[20, 30, 45, 60].map((n) => (
                      <button
                        key={n}
                        className={draft.time === n ? "selected" : ""}
                        onClick={() => setDraft({ ...draft, time: n })}
                      >
                        {n} min
                      </button>
                    ))}
                  </div>
                  <label className="field-label" htmlFor="preferences">
                    ANYTHING ELSE? · OPTIONAL
                  </label>
                  <textarea
                    id="preferences"
                    value={draft.notes}
                    onChange={(e) =>
                      setDraft({ ...draft, notes: e.target.value })
                    }
                    placeholder="Anything you’d like to keep in mind…"
                  />
                  <small className="form-note">
                    Notes are saved for your reference. Movement exclusions
                    guide the plan.
                  </small>
                </>
              )}
              {onboarding === 6 && (
                <>
                  <div className="generated-plan">
                    <span className="pill">{draft.goal.toUpperCase()}</span>
                    <h3>
                      {draft.goal === "Improve mobility"
                        ? "Mobility & control"
                        : "Full body foundation"}
                    </h3>
                    <p>
                      {draft.days} days / week · {draft.time} min / session ·{" "}
                      {draft.level}
                    </p>
                    <div className="mini-schedule">
                      {dayNames.map((d, i) => (
                        <span
                          className={
                            trainingDays(draft.days).includes(i) ? "train" : ""
                          }
                          key={d}
                        >
                          {d}
                          <small>
                            {trainingDays(draft.days).includes(i)
                              ? "Train"
                              : "Rest"}
                          </small>
                        </span>
                      ))}
                    </div>
                  </div>
                  {makePlan(draft)
                    .slice(0, 3)
                    .map((e, i) => (
                      <ExerciseRow
                        key={i}
                        exercise={e}
                        index={i}
                        sets={
                          draft.level === "Beginner"
                            ? 2
                            : draft.level === "Advanced"
                              ? 4
                              : 3
                        }
                      />
                    ))}
                  <small className="form-note">
                    A locally generated starting plan, not medical advice. Keep
                    every movement comfortable.
                  </small>
                </>
              )}
            </div>
            <div className="onboarding-actions">
              {onboarding > 0 && (
                <Button secondary onClick={() => setOnboarding(onboarding - 1)}>
                  <Icon name="back" />
                  Back
                </Button>
              )}
              <Button
                disabled={
                  (onboarding === 1 && !draft.goal) ||
                  (onboarding === 2 && !draft.level) ||
                  (onboarding === 3 && !draft.environment)
                }
                onClick={() => {
                  if (onboarding < 6) setOnboarding(onboarding + 1)
                  else {
                    setPrefs(draft)
                    setOverrides({})
                    setOnboarded(true)
                    setOnboarding(null)
                    setTab("Home")
                    setScreen("main")
                  }
                }}
              >
                {onboarding === 6
                  ? "Make this my plan"
                  : onboarding === 0
                    ? "Let’s get started"
                    : "Continue"}
                <Icon name="arrow" />
              </Button>
            </div>
          </Glass>
        </GlassOverlay>
      )}
      {confirm && (
        <GlassOverlay className="confirmation-overlay" label="Confirm action">
          <Glass className="modal confirmation">
            <span className="eyebrow">A QUICK CHECK</span>
            <h2>
              {confirm === "reset"
                ? "Start with a clean slate?"
                : "Finish this session?"}
            </h2>
            <p>
              {confirm === "reset"
                ? "This removes all locally saved preferences, history, XP, and session progress. This cannot be undone."
                : "Save your completed sets, or discard this session. You can also keep going."}
            </p>
            {confirm === "reset" ? (
              <Button
                onClick={() => {
                  setPrefs(defaults)
                  setDraft(defaults)
                  setOnboarded(false)
                  setHistory([])
                  setTaskCompletions([])
                  setCoachMessages([])
                  setRankUp(null)
                  setSession(null)
                  setOverrides({})
                  setRestDefault(60)
                  setMotion(true)
                  setHaptics(false)
                  setConfirm(null)
                  setTab("Home")
                  setScreen("main")
                }}
              >
                Reset all local data
              </Button>
            ) : (
              <>
                <Button
                  disabled={!session?.completed}
                  onClick={() => session && finish(session)}
                >
                  Save completed sets
                </Button>
                <Button
                  secondary
                  onClick={() => {
                    setSession(null)
                    setConfirm(null)
                    setScreen("main")
                  }}
                >
                  Discard session
                </Button>
              </>
            )}
            <button className="text-button" onClick={() => setConfirm(null)}>
              {confirm === "reset" ? "Keep my data" : "Keep training"}
            </button>
          </Glass>
        </GlassOverlay>
      )}
    </div>
  )
}
